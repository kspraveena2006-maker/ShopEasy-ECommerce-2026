# ShopEasy - E-Commerce Web Application

A beginner-friendly coursework demo built with Flask, SQLite, HTML, CSS, and Jinja templates.

## Features
- Product listing and search
- Add products to cart and update quantities
- Checkout and create orders
- Track an order by order number
- Admin page to add, edit, and delete products
- Admin order status updates
- SQLite database is created and seeded automatically on first run

## Run on Windows PowerShell
From this folder:

```powershell
py -m venv venv
.\venv\Scripts\python.exe -m pip install flask
.\venv\Scripts\python.exe app.py
```

Open http://127.0.0.1:5000 in your browser.

## Important
This is a local learning/demo project. The admin page has no authentication and the Flask development server is not for public production deployment. Add authentication and production security before deploying publicly.
