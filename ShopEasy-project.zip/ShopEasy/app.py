from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key-for-your-own-project"
DB_PATH = Path(__file__).with_name("shop.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                price REAL NOT NULL,
                stock INTEGER NOT NULL DEFAULT 0,
                image_url TEXT NOT NULL DEFAULT ''
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                email TEXT NOT NULL,
                address TEXT NOT NULL,
                total REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Placed',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                product_id INTEGER,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                FOREIGN KEY(order_id) REFERENCES orders(id)
            )
        """)
        count = db.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count == 0:
            samples = [
                ("Wireless Headphones", "Comfortable headphones for music and calls.", 1499, 12, "https://images.unsplash.com/photo-150 headphones"),
                ("Smart Watch", "Everyday watch with fitness tracking style.", 2299, 8, "https://images.unsplash.com/photo-1523275335684-37898b6baf30"),
                ("Backpack", "A practical backpack for college and travel.", 999, 15, "https://images.unsplash.com/photo-1553062407-98eeb64c6a62"),
                ("Desk Lamp", "A clean, modern lamp for your study table.", 799, 10, "https://images.unsplash.com/photo-1507473885765-e6ed057f782c"),
            ]
            # Use valid, broadly accessible image URLs for demo product cards.
            samples[0] = ("Wireless Headphones", "Comfortable headphones for music and calls.", 1499, 12, "https://images.unsplash.com/photo-1505740420928-5e560c06d30e")
            db.executemany(
                "INSERT INTO products (name, description, price, stock, image_url) VALUES (?, ?, ?, ?, ?)",
                samples
            )

@app.context_processor
def cart_count():
    cart = session.get("cart", {})
    return {"cart_count": sum(int(q) for q in cart.values())}

@app.route("/")
def index():
    search = request.args.get("q", "").strip()
    with get_db() as db:
        if search:
            products = db.execute(
                "SELECT * FROM products WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC",
                (f"%{search}%", f"%{search}%")
            ).fetchall()
        else:
            products = db.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return render_template("index.html", products=products, search=search)

@app.post("/cart/add/<int:product_id>")
def add_to_cart(product_id):
    with get_db() as db:
        product = db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
    if not product:
        flash("Product not found.", "error")
        return redirect(url_for("index"))
    if product["stock"] < 1:
        flash("Sorry, this product is out of stock.", "error")
        return redirect(url_for("index"))
    cart = session.get("cart", {})
    key = str(product_id)
    cart[key] = min(int(cart.get(key, 0)) + 1, product["stock"])
    session["cart"] = cart
    flash(f'{product["name"]} added to your cart.', "success")
    return redirect(request.referrer or url_for("index"))

@app.route("/cart")
def cart():
    cart_data = session.get("cart", {})
    items, total = [], 0
    with get_db() as db:
        for product_id, quantity in cart_data.items():
            product = db.execute("SELECT * FROM products WHERE id = ?", (int(product_id),)).fetchone()
            if product:
                qty = min(int(quantity), product["stock"])
                if qty > 0:
                    line_total = product["price"] * qty
                    items.append({"product": product, "quantity": qty, "line_total": line_total})
                    total += line_total
    return render_template("cart.html", items=items, total=total)

@app.post("/cart/update")
def update_cart():
    cart = session.get("cart", {})
    with get_db() as db:
        for product_id in list(cart.keys()):
            try:
                qty = int(request.form.get(f"qty_{product_id}", "0"))
            except ValueError:
                qty = 0
            product = db.execute("SELECT stock FROM products WHERE id = ?", (int(product_id),)).fetchone()
            if not product or qty <= 0:
                cart.pop(product_id, None)
            else:
                cart[product_id] = min(qty, product["stock"])
    session["cart"] = cart
    flash("Cart updated.", "success")
    return redirect(url_for("cart"))

@app.post("/checkout")
def checkout():
    cart_data = session.get("cart", {})
    if not cart_data:
        flash("Your cart is empty.", "error")
        return redirect(url_for("cart"))
    name = request.form.get("customer_name", "").strip()
    email = request.form.get("email", "").strip()
    address = request.form.get("address", "").strip()
    if not name or not email or not address:
        flash("Please fill in your name, email, and delivery address.", "error")
        return redirect(url_for("cart"))

    with get_db() as db:
        order_lines, total = [], 0
        for product_id, quantity in cart_data.items():
            product = db.execute("SELECT * FROM products WHERE id = ?", (int(product_id),)).fetchone()
            qty = int(quantity)
            if not product or qty < 1 or product["stock"] < qty:
                flash("Stock changed for one of your products. Please review your cart.", "error")
                return redirect(url_for("cart"))
            line_total = product["price"] * qty
            total += line_total
            order_lines.append((product, qty))
        cursor = db.execute(
            "INSERT INTO orders (customer_name, email, address, total, status) VALUES (?, ?, ?, ?, 'Placed')",
            (name, email, address, total)
        )
        order_id = cursor.lastrowid
        for product, qty in order_lines:
            db.execute(
                "INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (?, ?, ?, ?, ?)",
                (order_id, product["id"], product["name"], qty, product["price"])
            )
            db.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (qty, product["id"]))
    session["cart"] = {}
    flash(f"Order placed successfully! Your order number is #{order_id}.", "success")
    return redirect(url_for("track_order", order_id=order_id))

@app.route("/orders")
def orders():
    return render_template("orders.html", order=None, items=[])

@app.post("/orders")
def find_order():
    order_id = request.form.get("order_id", "").strip()
    return redirect(url_for("track_order", order_id=order_id))

@app.route("/orders/<order_id>")
def track_order(order_id):
    order = None
    items = []
    if str(order_id).isdigit():
        with get_db() as db:
            order = db.execute("SELECT * FROM orders WHERE id = ?", (int(order_id),)).fetchone()
            if order:
                items = db.execute("SELECT * FROM order_items WHERE order_id = ?", (int(order_id),)).fetchall()
    return render_template("orders.html", order=order, items=items)

@app.route("/admin", methods=["GET", "POST"])
def admin():
    # Demo admin page for a local coursework project. Add authentication before public deployment.
    if request.method == "POST":
        action = request.form.get("action", "add")
        with get_db() as db:
            if action == "delete":
                db.execute("DELETE FROM products WHERE id = ?", (request.form.get("product_id"),))
                flash("Product deleted.", "success")
            elif action == "update":
                try:
                    product_id = int(request.form.get("product_id", "0"))
                    name = request.form.get("name", "").strip()
                    description = request.form.get("description", "").strip()
                    price = float(request.form.get("price", "0"))
                    stock = int(request.form.get("stock", "0"))
                    image_url = request.form.get("image_url", "").strip()
                    if not name or price < 0 or stock < 0:
                        raise ValueError
                    db.execute(
                        "UPDATE products SET name=?, description=?, price=?, stock=?, image_url=? WHERE id=?",
                        (name, description, price, stock, image_url, product_id)
                    )
                    flash("Product updated.", "success")
                except (ValueError, TypeError):
                    flash("Please enter valid product details.", "error")
            else:
                try:
                    name = request.form.get("name", "").strip()
                    description = request.form.get("description", "").strip()
                    price = float(request.form.get("price", "0"))
                    stock = int(request.form.get("stock", "0"))
                    image_url = request.form.get("image_url", "").strip()
                    if not name or price < 0 or stock < 0:
                        raise ValueError
                    db.execute(
                        "INSERT INTO products (name, description, price, stock, image_url) VALUES (?, ?, ?, ?, ?)",
                        (name, description, price, stock, image_url)
                    )
                    flash("Product added.", "success")
                except (ValueError, TypeError):
                    flash("Please enter valid product details.", "error")
        return redirect(url_for("admin"))
    with get_db() as db:
        products = db.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
        all_orders = db.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    return render_template("admin.html", products=products, orders=all_orders)

@app.post("/admin/order-status")
def update_order_status():
    status = request.form.get("status", "Placed")
    allowed = {"Placed", "Processing", "Shipped", "Delivered", "Cancelled"}
    if status not in allowed:
        status = "Placed"
    with get_db() as db:
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (status, request.form.get("order_id")))
    flash("Order status updated.", "success")
    return redirect(url_for("admin"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
